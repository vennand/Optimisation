function varargout = doc_dple(varargin)
    %DOC_DPLE Get the documentation string for a plugin.
    %
    %  char = DOC_DPLE(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(926, varargin{:});
end
