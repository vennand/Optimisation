function varargout = expm_n_out(varargin)
    %EXPM_N_OUT Get the number of expm solver outputs.
    %
    %  int = EXPM_N_OUT()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(929, varargin{:});
end
