function varargout = has_integrator(varargin)
    %HAS_INTEGRATOR Check if a particular plugin is available.
    %
    %  bool = HAS_INTEGRATOR(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(859, varargin{:});
end
