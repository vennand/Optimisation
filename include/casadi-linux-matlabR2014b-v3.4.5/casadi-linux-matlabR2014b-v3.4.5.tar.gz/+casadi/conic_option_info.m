function varargout = conic_option_info(varargin)
    %CONIC_OPTION_INFO Get documentation for a particular option.
    %
    %  char = CONIC_OPTION_INFO(char name, char op)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(874, varargin{:});
end
