function varargout = conic_options(varargin)
    %CONIC_OPTIONS Get all options for a plugin.
    %
    %  {char} = CONIC_OPTIONS(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(872, varargin{:});
end
