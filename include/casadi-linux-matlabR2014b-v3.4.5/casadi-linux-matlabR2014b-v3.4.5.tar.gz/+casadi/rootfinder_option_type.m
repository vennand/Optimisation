function varargout = rootfinder_option_type(varargin)
    %ROOTFINDER_OPTION_TYPE Get type info for a particular option.
    %
    %  char = ROOTFINDER_OPTION_TYPE(char name, char op)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(897, varargin{:});
end
