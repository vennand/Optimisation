function varargout = has_interpolant(varargin)
    %HAS_INTERPOLANT Check if a particular plugin is available.
    %
    %  bool = HAS_INTERPOLANT(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(934, varargin{:});
end
