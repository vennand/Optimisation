function varargout = rootfinder_n_in(varargin)
    %ROOTFINDER_N_IN Number of rootfinder inputs.
    %
    %  int = ROOTFINDER_N_IN()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(894, varargin{:});
end
